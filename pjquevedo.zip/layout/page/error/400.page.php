
<section id="" class="container content-section text-left">

    <div class="alert alert-warning text-center">
        <h1><i class="glyphicon glyphicon-warning-sign"></i> Ops! Temos Um Problema...</h1>
        <h2>Erro 400!</h2>
        <p>Nossos servidores sentiram que esta conexão está insegura :(<br /><br />
            Se você não for um robô do mal que quer destruir e semear maldade no nosso site, entre em contato com a gente! 
            <br /><br /><a href="./" title="Wide Technologies - Soluções em Tecnologia">Clique aqui e vá para a página inicial!</a></p>
    </div>
</section>
<!-- divide footer -->
<section class="container content-section text-center">
    <div class="separa-footer"></div>
</section>