
<section id="" class="container content-section text-left">

    <div class="alert alert-warning text-center">
        <h1><i class="glyphicon glyphicon-warning-sign"></i> Ops! Você não tem acesso aqui...</h1>
        <h2>Erro 403!</h2>
        <p>A página ou pasta que você procura está bloqueada para acesso. <a href="./" title="Wide Technologies - Soluções em Tecnologia">Clique aqui e vá para a página inicial!</a></p>
    </div>
</section>
<!-- divide footer -->
<section class="container content-section text-center">
    <div class="separa-footer"></div>
</section>