
<section id="" class="container content-section text-left">

    <div class="alert alert-warning text-center">
        <h1><i class="glyphicon glyphicon-warning-sign"></i> Ops! Temos Um Problema...</h1>
        <h2>Erro 500!</h2>
        <p>Este é um problema no nosso servidor, isso não é legal :( <br /><br />
            Tente acessar mais tarde, se o problema continuar ocorrendo, por favor, nos avise!
            <br /><br /><a href="./" title="Wide Technologies - Soluções em Tecnologia">Clique aqui e vá para a página inicial!</a></p>
    </div>
</section>
<!-- divide footer -->
<section class="container content-section text-center">
    <div class="separa-footer"></div>
</section>