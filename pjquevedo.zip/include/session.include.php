<?php

session_name('chamada2');
session_start();
