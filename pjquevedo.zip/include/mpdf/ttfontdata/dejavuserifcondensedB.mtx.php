<?php
$name='DejaVuSerifCondensed-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 939,
  'Descent' => -236,
  'CapHeight' => 939,
  'Flags' => 262148,
  'FontBBox' => '[-752 -389 1617 1235]',
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 540,
);
$up=-63;
$ut=44;
$ttffile='C:/xampp/htdocs/historico/include/mpdf/ttfonts/DejaVuSerifCondensed-Bold.ttf';
$TTCfontID='0';
$originalsize=283140;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavuserifcondensedB';
$panose=' 0 0 2 6 8 6 5 6 5 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>